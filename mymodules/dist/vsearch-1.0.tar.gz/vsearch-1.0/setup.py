from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The Head First python search tools',
    author='HF Python 2e',
    py_modules=['vsearch'],
)